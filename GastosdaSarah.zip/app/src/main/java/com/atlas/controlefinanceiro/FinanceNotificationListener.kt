package com.atlas.controlefinanceiro

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Locale

class FinanceNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val full = listOf(title, text, big).filter { it.isNotBlank() }.joinToString(" ")
        val lower = full.lowercase(Locale("pt", "BR"))

        // Só registra notificações que parecem movimentações financeiras Pix/transferência.
        if (!(lower.contains("pix") || lower.contains("transferência") || lower.contains("transferencia"))) return

        val amountRegex = Regex("(?:R\\$\\s*)?([0-9]{1,3}(?:\\.[0-9]{3})*,[0-9]{2}|[0-9]+,[0-9]{2})")
        val match = amountRegex.find(full) ?: return
        val amount = match.groupValues[1].replace(".", "").replace(",", ".").toDoubleOrNull() ?: return
        if (amount <= 0.0) return

        val incoming = listOf("recebido", "recebida", "recebeu", "creditado", "crédito recebido", "credito recebido", "entrada", "salário", "salario").any { lower.contains(it) }
        val outgoing = listOf("enviado", "enviada", "realizado", "realizada", "pagamento", "pago", "compra", "transferiu", "débito", "debito").any { lower.contains(it) }
        if (!incoming && !outgoing) return // evita adivinhar o sentido da movimentação
        val signed = if (incoming) amount else -amount

        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) { sbn.packageName }
        val name = title.ifBlank { if (incoming) "Pix/transferência recebida" else "Pix/transferência enviada" }

        val prefs = getSharedPreferences("gastos_sarah", MODE_PRIVATE)
        val fingerprint = "${sbn.packageName}|${sbn.postTime}|$full"
        if (prefs.getString("last_auto_tx_fingerprint", "") == fingerprint) return
        val index = prefs.getInt("auto_tx_count", 0)
        val edit = prefs.edit()
            .putString("auto_tx_${index}_name", name)
            .putString("auto_tx_${index}_source", appName)
            .putLong("auto_tx_${index}_value", java.lang.Double.doubleToRawLongBits(signed))
            .putLong("auto_tx_${index}_time", sbn.postTime)
            .putString("last_auto_tx_fingerprint", fingerprint)
            .putInt("auto_tx_count", index + 1)

        // Somente saídas confirmadas entram no controle de gastos do salário.
        if (signed < 0) {
            val current = prefs.getFloat("expense_total", 0f).toDouble()
            edit.putFloat("expense_total", (current + amount).toFloat())
        }
        edit.apply()
    }
}
